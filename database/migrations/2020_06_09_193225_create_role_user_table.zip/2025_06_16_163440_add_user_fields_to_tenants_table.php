<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::connection('landlord') // Important : spécifie la DB landlord
            ->table('tenants', function (Blueprint $table) {
//                $table->string('email')->unique()->nullable();
//                $table->string('password')->nullable();
//                $table->rememberToken(); // Pour auth "remember me"
//                $table->timestamp('email_verified_at')->nullable();
            });
    }

    public function down(): void
    {
        Schema::connection('landlord')
            ->table('tenants', function (Blueprint $table) {
                $table->dropColumn(['name', 'email', 'password', 'remember_token', 'email_verified_at']);
            });
    }
};
