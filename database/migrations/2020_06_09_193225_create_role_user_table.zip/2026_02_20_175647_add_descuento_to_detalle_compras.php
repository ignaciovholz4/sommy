<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('detalle_compras', function (Blueprint $table) {
            // ✅ agregamos el campo descuento como porcentaje
            $table->decimal('descuento', 5, 2)->default(0)->after('precio_unitario');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('detalle_compras', function (Blueprint $table) {
            $table->dropColumn('descuento');
        });
    }
};
